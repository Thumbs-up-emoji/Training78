"""Milestone-5 API-key authentication dependency.

Baseline security requirement: every route on the production API
(``app/production_api.py``) is protected by this dependency, which reads a
shared-secret key from the ``MILESTONE5_API_KEY`` environment variable and
compares it against the ``X-API-Key`` request header.

This is intentionally simple (a single static header check, not a session or
user model) because Milestone 5 is an observability/security/production
*wrapper* around the existing Milestone-3/4 engine, not new business logic.
An optional JWT-based stretch (``verify_jwt``) is included below for students
who want bearer-token auth instead of/alongside the static API key; it is not
required and is not wired into ``production_api.py`` by default.
"""

from __future__ import annotations

import os

from fastapi import Header, HTTPException, status

API_KEY_ENV_VAR = "MILESTONE5_API_KEY"
API_KEY_HEADER_NAME = "X-API-Key"


def _expected_api_key() -> str | None:
    """Reads the expected API key from the environment on every call (rather
    than caching at import time) so tests can monkeypatch the environment
    variable freely without reloading this module.
    """
    return os.getenv(API_KEY_ENV_VAR)


async def verify_api_key(x_api_key: str | None = Header(default=None, alias=API_KEY_HEADER_NAME)) -> str:
    """FastAPI dependency enforcing the ``X-API-Key`` header on every request.

    Raises ``HTTPException(401)`` when the header is missing, when no server
    key is configured (fail-closed, not fail-open), or when the key does not
    match. Returns the validated key on success so it can be used as a
    dependency return value if a route wants to log/echo it (never do this
    with the raw key in production; ``app/production_api.py`` never logs it).
    """
    expected = _expected_api_key()
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server misconfiguration: {API_KEY_ENV_VAR} is not set.",
        )
    if not x_api_key or x_api_key != expected:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid API key. Provide it via the X-API-Key header.",
        )
    return x_api_key


def verify_jwt(token: str, secret: str | None = None, algorithms: tuple[str, ...] = ("HS256",)) -> dict:
    """Optional JWT verification stretch goal (not wired into the default API).

    Decodes and validates a bearer JWT using ``pyjwt`` against
    ``MILESTONE5_JWT_SECRET`` (or an explicitly supplied ``secret``). Raises
    ``jwt.InvalidTokenError`` subclasses on failure, which callers should map
    to ``HTTPException(401)``.
    """
    import jwt as pyjwt

    resolved_secret = secret or os.getenv("MILESTONE5_JWT_SECRET")
    if not resolved_secret:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Server misconfiguration: MILESTONE5_JWT_SECRET is not set.",
        )
    return pyjwt.decode(token, resolved_secret, algorithms=list(algorithms))
