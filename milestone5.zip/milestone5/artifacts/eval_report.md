# LLM Evaluation Report

- Report ID: `005dcd0e-62d7-4ada-9530-1b16a6e13bd5`
- Generated At: 2026-08-14T05:42:32.075742+00:00
- Total Cases: 2
- Passed: 2 (100%)
- Average Correctness: 0.933
- Average Groundedness: 0.6637
- Average Faithfulness: 0.6637
- Hallucination Rate: 0%
- LangSmith Tracing Enabled: False

## Case Results

| Case | Prompt | Passed | Correctness | Groundedness | Faithfulness | Hallucinated |
|---|---|---|---|---|---|---|
| 1 | Summarize quarterly sales | PASS | 0.866 | 0.75 | 0.75 | False |
| 2 | Top competitor by revenue | PASS | 1.0 | 0.5774 | 0.5774 | False |
